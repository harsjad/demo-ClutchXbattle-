//For Play tab at selected home page
package com.di.battlemaniaV5.ui.fragments;

import static com.android.volley.Request.Method.GET;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.di.battlemaniaV5.R;
import com.di.battlemaniaV5.models.BanerData;
import com.di.battlemaniaV5.models.CurrentUser;
import com.di.battlemaniaV5.models.GameData;
import com.di.battlemaniaV5.ui.activities.AnnouncementActivity;
import com.di.battlemaniaV5.ui.activities.MainActivity;
import com.di.battlemaniaV5.ui.activities.MyWalletActivity;
import com.di.battlemaniaV5.ui.adapters.GameAdapter;
import com.di.battlemaniaV5.ui.adapters.TestFragmentAdapter;
import com.di.battlemaniaV5.utils.KKViewPager;
import com.di.battlemaniaV5.utils.LoadingDialog;
import com.di.battlemaniaV5.utils.LocaleHelper;
import com.di.battlemaniaV5.utils.UserLocalStore;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import me.toptas.fancyshowcase.FancyShowCaseView;
import me.toptas.fancyshowcase.FocusShape;
import me.toptas.fancyshowcase.listener.DismissListener;

public class PlayFragment extends Fragment {

    TextView appname;
    CardView balance;
    RequestQueue mQueue, dQueue, sQueue;
    TextView balInPlay;
    UserLocalStore userLocalStore;
    TextView noUpcoming;
    LoadingDialog loadingDialog;
    ShimmerFrameLayout shimer;
    CurrentUser user;
    LinearLayout allGameLl;
    SwipeRefreshLayout pullToRefresh;
    TextView announcement;
    CardView announcecv;
    Context context;
    Resources resources;
    KKViewPager mPager;
    RecyclerView gameRv;
    GameAdapter gameAdapter;
    List<GameData> gameData;
    LinearLayout visiblelinear;
    private StaggeredGridLayoutManager manager;
    int currentPage = 0;
    Timer timer;
    TabLayout tabLayout;
    List<BanerData> banerData;
    JSONArray arr;
    SharedPreferences sp;

    @SuppressLint("ClickableViewAccessibility")
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        View root = inflater.inflate(R.layout.play_home, container, false);

        sp = requireActivity().getSharedPreferences("tabitem", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor1111 = sp.edit();
        String pagenumber = sp.getString("TAB", "0");


        gameData = new ArrayList<>();
        gameRv = root.findViewById(R.id.allgamerv);
        manager = new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL);
        /*gameRv.setHasFixedSize(true);*/
        gameRv.setLayoutManager(manager);

        context = LocaleHelper.setLocale(getContext());
        resources = context.getResources();
        tabLayout = root.findViewById(R.id.tablayoutmycontest);
        visiblelinear = root.findViewById(R.id.visiblelinear);

        if (TextUtils.equals(pagenumber, "1")) {
            Objects.requireNonNull(tabLayout.getTabAt(1)).select();
        } else {
            Objects.requireNonNull(tabLayout.getTabAt(0)).select();
        }

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                gameRv.removeAllViews();
                editor1111.putString("TAB", String.valueOf(tab.getPosition()));
                editor1111.apply();
                try {
                    gameAdapter.notifyDataSetChanged();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                checkgame();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                Log.d("tab contest re", String.valueOf(tab.getPosition()));
            }
        });

        pullToRefresh = root.findViewById(R.id.pullToRefreshplay);
        pullToRefresh.setOnRefreshListener(this::refresh);

        mPager = root.findViewById(R.id.kk_pager);

        banerData = new ArrayList<>();

        loadingDialog = new LoadingDialog(getContext());
        shimer = root.findViewById(R.id.shimmerplay);
        userLocalStore = new UserLocalStore(getContext());
        user = userLocalStore.getLoggedInUser();

        // Log.d("sony", user.getToken());

        appname = root.findViewById(R.id.appnamid);
        allGameLl = root.findViewById(R.id.allgamell);
        balInPlay = root.findViewById(R.id.balinplay);
        balance = root.findViewById(R.id.balanceinplay);
        balance.setEnabled(true);
        balInPlay.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), MyWalletActivity.class);
            intent.putExtra("FROM", "PLAY");
            startActivity(intent);
        });

        appname.setText(resources.getString(R.string.app_name));
        announcement = root.findViewById(R.id.announce);
        announcecv = root.findViewById(R.id.announccv);
        announcecv.setVisibility(View.GONE);
        announcement.setOnClickListener(v -> startActivity(new Intent(getActivity(), AnnouncementActivity.class)));
        Announcement();


        mQueue = Volley.newRequestQueue(getContext());
        mQueue.getCache().clear();
        noUpcoming = root.findViewById(R.id.noupcominginplay1);

        Objects.requireNonNull(tabLayout.getTabAt(0)).setText(resources.getString(R.string.tournament));
        Objects.requireNonNull(tabLayout.getTabAt(1)).setText(resources.getString(R.string.solo));

        /*dashboard start*/
        dQueue = Volley.newRequestQueue(getContext());
        String url = resources.getString(R.string.api) + "dashboard/" + user.getMemberid();
        @SuppressLint("DefaultLocale") final JsonObjectRequest drequest = new JsonObjectRequest(url, null,
                response -> {
                    try {
                        Log.d("dash", response.toString());
                        JSONObject memobj = new JSONObject(response.getString("member"));
                        if (TextUtils.equals(memobj.getString("member_status"), "0")) {
                            if (!user.getUsername().isEmpty() && !user.getPassword().isEmpty()) {
                                userLocalStore.clearUserData();
                                Toast.makeText(getActivity(), resources.getString(R.string.your_account_is_blocked_by_admin), Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getActivity(), MainActivity.class));
                            }
                            return;
                        }

                        String winMoney = memobj.getString("wallet_balance");
                        String joinMoney = memobj.getString("join_money");

                        if (TextUtils.equals(winMoney, "null")) {
                            winMoney = "0";
                        }
                        if (TextUtils.equals(joinMoney, "null")) {
                            joinMoney = "0";
                        }

                        String win = "";
                        if (isDouble(winMoney)) {
                            win = String.format("%.2f", Double.parseDouble(winMoney));
                        } else {
                            win = String.valueOf(Integer.parseInt(winMoney));
                        }

                        String joinm = "";
                        if (isDouble(joinMoney)) {
                            joinm = String.format("%.2f", Double.parseDouble(joinMoney));
                        } else {
                            joinm = String.valueOf(Integer.parseInt(joinMoney));
                        }

                        String totalMoney = "";
                        if(win.startsWith("0")){
                            if (isDouble(joinm)) {
                                totalMoney = String.valueOf(Double.parseDouble(joinm));
                            } else {
                                totalMoney = String.valueOf(Integer.parseInt(joinm));
                            }
                        }else if(joinm.startsWith("-")){
                            if (isDouble(win)) {
                                totalMoney = String.valueOf(Double.parseDouble(win));
                            } else {
                                totalMoney = String.valueOf(Integer.parseInt(win));
                            }
                        }else {
                            if (isDouble(win) && isDouble(joinm)) {
                                totalMoney = String.valueOf(Double.parseDouble(win) + Double.parseDouble(joinm));
                            } else {
                                totalMoney = String.valueOf(Integer.parseInt(win) + Integer.parseInt(joinm));
                            }
                        }
                        if (isDouble(totalMoney)) {
                            totalMoney = String.format("%.2f", Double.parseDouble(totalMoney));
                        }
                        /// Assigning the bigdecimal value of ln to
                        balInPlay.setText(totalMoney);
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                }, error -> Log.e("**VolleyError", "error" + error.getMessage())) {
            @Override
            protected Map<String, String> getParams() throws
                    AuthFailureError {
                return super.getParams();
            }

            @Override
            public Map<String, String> getHeaders() {

                Map<String, String> headers = new HashMap<>();
                CurrentUser user = userLocalStore.getLoggedInUser();
                String token = "Bearer " + user.getToken();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                Log.d("sony", token);
                headers.put("x-localization", LocaleHelper.getPersist(context));
                return headers;
            }
        };

        drequest.setShouldCache(false);
        dQueue.add(drequest);

        /*dashboard end*/
        viewallslider();
        return root;
    }

    boolean isDouble(String str) {
        try {
            Double.parseDouble(str);
            return true;
        }
        catch (NumberFormatException e) {
            return false;
        }
    }

    public void viewallgame() {
        /*all_game api call start*/
        mQueue = Volley.newRequestQueue(getContext());
        mQueue.getCache().clear();
        String jurl = resources.getString(R.string.api) + "all_game";
        final UserLocalStore userLocalStore = new UserLocalStore(getContext());

        final JsonObjectRequest request = new JsonObjectRequest(GET, jurl, null,
                response -> {
                    try {
                        arr = response.getJSONArray("all_game");
                        JSON_PARSE_DATA_AFTER_WEBCALL(arr);
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                    loadingDialog.dismiss();
                }, error -> Log.e("**VolleyError", "error" + error.getMessage())) {
            @Override
            protected Map<String, String> getParams() throws
                    AuthFailureError {
                return super.getParams();
            }

            @Override
            public Map<String, String> getHeaders() {

                Map<String, String> headers = new HashMap<>();
                CurrentUser user = userLocalStore.getLoggedInUser();
                String token = "Bearer " + user.getToken();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                Log.d("sx", token);
                headers.put("x-localization", LocaleHelper.getPersist(context));
                return headers;
            }
        };
        request.setShouldCache(false);
        mQueue.add(request);
        /*all_game api call end*/
    }

    private void checkgame() {
        noUpcoming.setVisibility(View.GONE);
        gameRv.setVisibility(View.VISIBLE);
        List<String> issues = new ArrayList<>();
        int list = arr.length();
        for (int i = 0; i < list; i++) {
            try {
                JSONObject json = arr.getJSONObject(i);
                if (TextUtils.equals(sp.getString("TAB", "0"), json.getString("game_type"))) {
                    issues.add(String.valueOf(i));
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (issues.isEmpty()) {
            gameRv.setVisibility(View.GONE);
            if (noUpcoming.getVisibility() != View.VISIBLE) {
                noUpcoming.setVisibility(View.VISIBLE);
            }
        }
        issues.clear();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void JSON_PARSE_DATA_AFTER_WEBCALL(JSONArray array) {
        for (int i = 0; i < array.length(); i++) {
            try {
                JSONObject json;
                json = array.getJSONObject(i);
                final GameData data = new GameData(json.getString("game_id"), json.getString("game_name"), json.getString("game_image"), json.getString("status"), json.getString("total_upcoming_match"), json.getString("game_type"), json.getString("total_upcoming_challenge"), json.getString("package_name"), json.getString("coming_soon"));
                Log.d(data.getGameName(),data.getGameImage());
                gameData.add(data);
                gameAdapter = new GameAdapter(getActivity(), gameData);
                gameAdapter.notifyDataSetChanged();
                gameRv.setAdapter(gameAdapter);
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }
        checkgame();
    }

    public void refresh() {
        requireActivity().finish();
        requireActivity().overridePendingTransition(0, 0);
        Intent intent = requireActivity().getIntent();
        intent.putExtra("N", "1");
        requireActivity().startActivity(intent);
        requireActivity().overridePendingTransition(0, 0);
    }

    public void Announcement() {

        //for announcement api
        mQueue = Volley.newRequestQueue(requireContext());
        mQueue.getCache().clear();
        String vurl = resources.getString(R.string.api) + "announcement";
        final UserLocalStore userLocalStore = new UserLocalStore(requireContext());

        final JsonObjectRequest request = new JsonObjectRequest(GET, vurl, null,
                response -> {
                    try {
                        Log.d("announce", response.toString());
                        JSONArray arr = response.getJSONArray("announcement");

                        if (!TextUtils.equals(response.getString("announcement"), "[]")) {
                            announcecv.setVisibility(View.GONE);
                        } else {
                            announcecv.setVisibility(View.GONE);
                            announcement.setText(Html.fromHtml("<b>" + resources.getString(R.string.announcement) + "</b><br>" + resources.getString(R.string.no_announcement_available)));
                        }
                        announcement.setClickable(true);
                        announcement.setMovementMethod(LinkMovementMethod.getInstance());
                        JSON_PARSE_DATA_AFTER_WEBCALLannounccement(arr);
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }

                }, error -> Log.e("**VolleyError", "error" + error.getMessage())) {
            @Override
            protected Map<String, String> getParams() throws
                    AuthFailureError {
                return super.getParams();
            }

            @Override
            public Map<String, String> getHeaders() {

                Map<String, String> headers = new HashMap<>();
                CurrentUser user = userLocalStore.getLoggedInUser();
                String token = "Bearer " + user.getToken();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);


                headers.put("x-localization", LocaleHelper.getPersist(context));
                return headers;
            }
        };
        request.setShouldCache(false);
        mQueue.add(request);
    }

    public void viewallslider() {

        /*slider api call start*/
        sQueue = Volley.newRequestQueue(getActivity());
        sQueue.getCache().clear();
        String kurl = resources.getString(R.string.api) + "slider";
        final UserLocalStore userLocalStore = new UserLocalStore(getContext());

        final JsonObjectRequest srequest = new JsonObjectRequest(GET, kurl, null,
                response -> {
                    try {
                        Log.d("slider", response.toString());
                        JSONArray arr = response.getJSONArray("slider");

                        if (TextUtils.equals(response.getString("slider"), "[]")) {
                            mPager.setVisibility(View.GONE);
                            visiblelinear.setVisibility(View.VISIBLE);
                        } else {
                            mPager.setVisibility(View.VISIBLE);
                            visiblelinear.setVisibility(View.GONE);
                        }

                        JSON_PARSE_DATA_AFTER_WEBCALLslider(arr);
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                    loadingDialog.dismiss();
                }, error -> Log.e("**VolleyError", "error" + error.getMessage())) {
            @Override
            protected Map<String, String> getParams() throws
                    AuthFailureError {
                return super.getParams();
            }

            @Override
            public Map<String, String> getHeaders() {

                Map<String, String> headers = new HashMap<>();
                CurrentUser user = userLocalStore.getLoggedInUser();
                String token = "Bearer " + user.getToken();
                headers.put("Content-Type", "application/json");
                headers.put("Authorization", token);
                headers.put("x-localization", "en");
                return headers;
            }
        };
        srequest.setShouldCache(false);
        sQueue.add(srequest);
        /*slider api call end*/
        viewallgame();
    }

    public void JSON_PARSE_DATA_AFTER_WEBCALLslider(JSONArray array) {

        banerData.clear();
        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            try {
                json = array.getJSONObject(i);
                BanerData data = new BanerData(json.getString("slider_id"), json.getString("slider_title"), json.getString("slider_image"), json.getString("slider_link_type"), json.getString("slider_link"), json.getString("link_id"), json.getString("game_name"));
                banerData.add(data);
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }

        mPager.setAdapter(new TestFragmentAdapter(requireActivity().getSupportFragmentManager(),
                getActivity(), banerData));
        mPager.setPageMargin(40);
        mPager.setAnimationEnabled(true);
        mPager.setFadeEnabled(true);
        mPager.setFadeFactor(0.6f);

        /*After setting the adapter use the timer */
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {

            public void run() {
                if (currentPage == banerData.size()) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };


        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 2000, 2000);

    }

    public void JSON_PARSE_DATA_AFTER_WEBCALLannounccement(JSONArray array) {

        for (int i = 0; i < array.length(); i++) {
            JSONObject json;
            announcecv.setVisibility(View.VISIBLE);
            try {
                json = array.getJSONObject(i);
                announcement.setText(Html.fromHtml("<b>" + resources.getString(R.string.announcement) + "</b><br>" + json.getString("announcement_desc")));
                announcement.setClickable(true);
                announcement.setMovementMethod(LinkMovementMethod.getInstance());
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public FancyShowCaseView addView(View view, String title, String n) {
        FancyShowCaseView view1 = new FancyShowCaseView.Builder(getActivity())
                .focusOn(view)
                .title(title)
                //.titleGravity(Gravity.BOTTOM)
                .titleSize(20, 1)
                .focusShape(FocusShape.CIRCLE)
                .enableAutoTextPosition()
                .roundRectRadius(10)
                .focusBorderSize(1)
                .showOnce(n)
                .focusBorderColor(getActivity().getResources().getColor(R.color.newblue))
                .dismissListener(new DismissListener() {
                    @Override
                    public void onDismiss(String s) {

                    }

                    @Override
                    public void onSkipped(String s) {

                    }
                })
                .build();

        return view1;
    }

}
